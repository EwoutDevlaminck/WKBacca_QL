# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.plot_range_handles_item import PlotRangeHandlesItem


class RangeHandlesItem(PlotRangeHandlesItem):
    r"""
    RangeHandlesItem - item to show and control the range of a
    ColorTransferFunction
    
    Superclass: PlotRangeHandlesItem
    
    RangeHandlesItem provides range handles painting and management
    for a provided ColorTransferFunction. This specialization of
    PlotRangeHandlesItem works in coordination with the color transfer
    function to drive the behavior of handles. Handles can only be
    dragged within the color transfer function range and are forced to be
    placed vertically with a fixed height of 1.
    
    A typical use case for this class is to observe end_interaction_event
    to update the color transfer function range using the handles range.
    
    @sa
    ControlPointsItem ScalarsToColorsItem
    ColorTransferFunctionItem
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkRangeHandlesItem, obj, update, **traits)
    
    def _get_color_transfer_function(self):
        return wrap_vtk(self._vtk_obj.GetColorTransferFunction())
    def _set_color_transfer_function(self, arg):
        old_val = self._get_color_transfer_function()
        self._wrap_call(self._vtk_obj.SetColorTransferFunction,
                        deref_vtk(arg))
        self.trait_property_changed('color_transfer_function', old_val, arg)
    color_transfer_function = traits.Property(_get_color_transfer_function, _set_color_transfer_function, desc=\
        r"""
        
        """
    )

    def _get_input(self):
        return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input, desc=\
        r"""
        Get the input table used by the plot.
        """
    )

    _updateable_traits_ = \
    (('extent_to_axis_range', 'GetExtentToAxisRange'),
    ('lock_tooltip_to_mouse', 'GetLockTooltipToMouse'),
    ('synchronize_range_handles', 'GetSynchronizeRangeHandles'),
    ('legend_visibility', 'GetLegendVisibility'), ('selectable',
    'GetSelectable'), ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('handle_orientation',
    'GetHandleOrientation'), ('extent', 'GetExtent'), ('handle_width',
    'GetHandleWidth'), ('label', 'GetLabel'), ('tooltip_label_format',
    'GetTooltipLabelFormat'), ('tooltip_notation', 'GetTooltipNotation'),
    ('tooltip_precision', 'GetTooltipPrecision'),
    ('use_index_for_x_series', 'GetUseIndexForXSeries'), ('width',
    'GetWidth'), ('opacity', 'GetOpacity'), ('interactive',
    'GetInteractive'), ('visible', 'GetVisible'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'extent_to_axis_range', 'global_warning_display',
    'legend_visibility', 'lock_tooltip_to_mouse', 'selectable',
    'synchronize_range_handles', 'handle_orientation', 'extent',
    'handle_width', 'interactive', 'label', 'object_name', 'opacity',
    'tooltip_label_format', 'tooltip_notation', 'tooltip_precision',
    'use_index_for_x_series', 'visible', 'width'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(RangeHandlesItem, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit RangeHandlesItem properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['extent_to_axis_range', 'legend_visibility',
            'lock_tooltip_to_mouse', 'selectable', 'synchronize_range_handles'],
            ['handle_orientation'], ['extent', 'handle_width', 'interactive',
            'label', 'object_name', 'opacity', 'tooltip_label_format',
            'tooltip_notation', 'tooltip_precision', 'use_index_for_x_series',
            'visible', 'width']),
            title='Edit RangeHandlesItem properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit RangeHandlesItem properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

