# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.actor import Actor


class PolarAxesActor(Actor):
    r"""
    PolarAxesActor - create an actor of a polar axes -
    
    Superclass: Actor
    
    PolarAxesActor is a composite actor that draws polar axes in a
    specified plane for a give pole. Currently the plane has to be the xy
    plane.
    
    @par Thanks: This class was written by Philippe Pebay, Kitware SAS
    2011. This work was supported by CEA/DIF - Commissariat a l'Energie
    Atomique, Centre DAM Ile-De-France, BP12, F-91297 Arpajon, France.
    
    @sa
    Actor AxisActor PolarAxesActor
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPolarAxesActor, obj, update, **traits)
    
    arc_minor_tick_visibility = tvtk_base.false_bool_trait(desc=\
        r"""
        Turn on and off the visibility of minor ticks on the last arc.
        Default: false.
        """
    )

    def _arc_minor_tick_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcMinorTickVisibility,
                        self.arc_minor_tick_visibility_)

    arc_tick_matches_radial_axes = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the use of radial axes angle for arc major ticks.
        Default: true.
        """
    )

    def _arc_tick_matches_radial_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcTickMatchesRadialAxes,
                        self.arc_tick_matches_radial_axes_)

    arc_tick_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of major ticks on the last arc.
        Default: true.
        """
    )

    def _arc_tick_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcTickVisibility,
                        self.arc_tick_visibility_)

    arc_ticks_origin_to_polar_axis = tvtk_base.true_bool_trait(desc=\
        r"""
        If On, the ticks are drawn from the angle of the polarAxis (i.e.
        this->minimal_radius) and continue counterclockwise with the step
        delta_angle Major/Minor. if Off, the start angle is 0.0, i.e. the
        angle on the major radius of the ellipse. Default: true.
        """
    )

    def _arc_ticks_origin_to_polar_axis_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcTicksOriginToPolarAxis,
                        self.arc_ticks_origin_to_polar_axis_)

    auto_subdivide_polar_axis = tvtk_base.false_bool_trait(desc=\
        r"""
        Set/Get whether the number of polar axis ticks and arcs should be
        automatically calculated. Default: false.
        """
    )

    def _auto_subdivide_polar_axis_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAutoSubdividePolarAxis,
                        self.auto_subdivide_polar_axis_)

    axis_minor_tick_visibility = tvtk_base.false_bool_trait(desc=\
        r"""
        Turn on and off the visibility of minor ticks on polar axis and
        last radial axis. Default: false.
        """
    )

    def _axis_minor_tick_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAxisMinorTickVisibility,
                        self.axis_minor_tick_visibility_)

    axis_tick_matches_polar_axes = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the use of polar axes range for axis major ticks.
        Default: true.
        """
    )

    def _axis_tick_matches_polar_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAxisTickMatchesPolarAxes,
                        self.axis_tick_matches_polar_axes_)

    axis_tick_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of major ticks on polar axis and
        last radial axis. Default: true.
        """
    )

    def _axis_tick_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetAxisTickVisibility,
                        self.axis_tick_visibility_)

    draw_polar_arcs_gridlines = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of inner polar arcs grid lines
        Default: true.
        """
    )

    def _draw_polar_arcs_gridlines_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDrawPolarArcsGridlines,
                        self.draw_polar_arcs_gridlines_)

    draw_radial_gridlines = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of inner radial grid lines
        Default: true.
        """
    )

    def _draw_radial_gridlines_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDrawRadialGridlines,
                        self.draw_radial_gridlines_)

    log = tvtk_base.false_bool_trait(desc=\
        r"""
        Enable/Disable log scale. Default: false.
        """
    )

    def _log_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLog,
                        self.log_)

    polar_arcs_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of arcs for polar axis. Default:
        true.
        """
    )

    def _polar_arcs_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarArcsVisibility,
                        self.polar_arcs_visibility_)

    polar_axis_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of the polar axis. Default: true.
        """
    )

    def _polar_axis_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisVisibility,
                        self.polar_axis_visibility_)

    polar_label_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of labels for polar axis. Default:
        true.
        """
    )

    def _polar_label_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarLabelVisibility,
                        self.polar_label_visibility_)

    polar_tick_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the overall visibility of ticks. Default: true.
        """
    )

    def _polar_tick_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarTickVisibility,
                        self.polar_tick_visibility_)

    polar_title_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of titles for polar axis. Default:
        true.
        """
    )

    def _polar_title_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarTitleVisibility,
                        self.polar_title_visibility_)

    radial_axes_origin_to_polar_axis = tvtk_base.true_bool_trait(desc=\
        r"""
        If On, the radial axes are drawn from the angle of the polarAxis
        (i.e. this->minimal_radius) and continue counterclockwise with the
        step delta_angle_radial_axes. if Off, the start angle is 0.0, i.e.
        the angle on the major radius of the ellipse. Default: true.
        """
    )

    def _radial_axes_origin_to_polar_axis_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialAxesOriginToPolarAxis,
                        self.radial_axes_origin_to_polar_axis_)

    radial_axes_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of non-polar radial axes. Default:
        true.
        """
    )

    def _radial_axes_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialAxesVisibility,
                        self.radial_axes_visibility_)

    radial_title_visibility = tvtk_base.true_bool_trait(desc=\
        r"""
        Turn on and off the visibility of titles for non-polar radial
        axes. Default: true.
        """
    )

    def _radial_title_visibility_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialTitleVisibility,
                        self.radial_title_visibility_)

    arc_major_tick_size = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the size of the major ticks on the last arc. If set to 0,
        compute it as a ratio of maximum radius. Default 0.
        """
    )

    def _arc_major_tick_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcMajorTickSize,
                        self.arc_major_tick_size)

    arc_major_tick_thickness = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the size of the thickness of the last arc ticks. Default:
        1.
        """
    )

    def _arc_major_tick_thickness_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcMajorTickThickness,
                        self.arc_major_tick_thickness)

    arc_tick_ratio_size = traits.Float(0.3, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between major and minor Arc ticks size.
        Default: 0.3.
        """
    )

    def _arc_tick_ratio_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcTickRatioSize,
                        self.arc_tick_ratio_size)

    arc_tick_ratio_thickness = traits.Float(0.5, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between major and minor Arc ticks thickness.
        Default: 0.5.
        """
    )

    def _arc_tick_ratio_thickness_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetArcTickRatioThickness,
                        self.arc_tick_ratio_thickness)

    bounds = traits.Array(enter_set=True, auto_set=False, shape=(6,), dtype="float", value=(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0), cols=3, desc=\
        r"""
        Explicitly specify the region in space around which to draw the
        bounds. The bounds are used only when no Input or Prop is
        specified. The bounds are specified according to (xmin,xmax,
        ymin,ymax, zmin,zmax), making sure that the min's are less than the
        max's. Default: (-1, 1, -1, 1, -1, 1).
        """
    )

    def _bounds_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetBounds,
                        self.bounds)

    def _get_camera(self):
        return wrap_vtk(self._vtk_obj.GetCamera())
    def _set_camera(self, arg):
        old_val = self._get_camera()
        self._wrap_call(self._vtk_obj.SetCamera,
                        deref_vtk(arg))
        self.trait_property_changed('camera', old_val, arg)
    camera = traits.Property(_get_camera, _set_camera, desc=\
        r"""
        
        """
    )

    delta_angle_major = traits.Float(45.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the angle between 2 major ticks on the last arc. Default:
        45.
        """
    )

    def _delta_angle_major_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDeltaAngleMajor,
                        self.delta_angle_major)

    delta_angle_minor = traits.Float(22.5, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the angle between 2 minor ticks on the last arc. Default:
        22.5.
        """
    )

    def _delta_angle_minor_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDeltaAngleMinor,
                        self.delta_angle_minor)

    delta_range_major = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the range between 2 major ticks (values displayed on the
        axis). Default: 1.
        """
    )

    def _delta_range_major_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDeltaRangeMajor,
                        self.delta_range_major)

    delta_range_minor = traits.Float(0.5, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the range between 2 minor ticks. Default: 0.5.
        """
    )

    def _delta_range_minor_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDeltaRangeMinor,
                        self.delta_range_minor)

    distance_lod_threshold = traits.Trait(0.7, traits.Range(0.0, 1.0, enter_set=True, auto_set=False), desc=\
        r"""
        Set distance LOD threshold [0.0 - 1.0] for titles and labels.
        Default: 0.7.
        """
    )

    def _distance_lod_threshold_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetDistanceLODThreshold,
                        self.distance_lod_threshold)

    enable_distance_lod = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        Enable and disable the use of distance based LOD for titles and
        labels. Default: true.
        """
    )

    def _enable_distance_lod_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetEnableDistanceLOD,
                        self.enable_distance_lod)

    enable_view_angle_lod = traits.Int(1, enter_set=True, auto_set=False, desc=\
        r"""
        Enable and disable the use of view angle based LOD for titles and
        labels. Default: true.
        """
    )

    def _enable_view_angle_lod_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetEnableViewAngleLOD,
                        self.enable_view_angle_lod)

    exponent_location = traits.Trait(2, traits.Range(0, 2, enter_set=True, auto_set=False), desc=\
        r"""
        Get/Set the location of the exponent (if any) of the polar axis
        values. Possible location: VTK_EXPONENT_BOTTOM,
        VTK_EXPONENT_EXTERN, VTK_EXPONENT_LABELS
        """
    )

    def _exponent_location_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetExponentLocation,
                        self.exponent_location)

    last_axis_tick_ratio_size = traits.Float(0.3, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between major and minor Last Radial axis ticks
        size. Default: 0.3.
        """
    )

    def _last_axis_tick_ratio_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLastAxisTickRatioSize,
                        self.last_axis_tick_ratio_size)

    last_axis_tick_ratio_thickness = traits.Float(0.5, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between major and minor Last Radial axis ticks
        thickness. Default: 0.5.
        """
    )

    def _last_axis_tick_ratio_thickness_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLastAxisTickRatioThickness,
                        self.last_axis_tick_ratio_thickness)

    last_radial_axis_major_tick_size = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the size of the major ticks on the last radial axis. If
        set to 0, compute it as a ratio of maximum radius. Default 0.
        """
    )

    def _last_radial_axis_major_tick_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLastRadialAxisMajorTickSize,
                        self.last_radial_axis_major_tick_size)

    last_radial_axis_major_tick_thickness = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the size of the thickness of last radial axis ticks.
        Default: 1.
        """
    )

    def _last_radial_axis_major_tick_thickness_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLastRadialAxisMajorTickThickness,
                        self.last_radial_axis_major_tick_thickness)

    def _get_last_radial_axis_property(self):
        return wrap_vtk(self._vtk_obj.GetLastRadialAxisProperty())
    def _set_last_radial_axis_property(self, arg):
        old_val = self._get_last_radial_axis_property()
        self._wrap_call(self._vtk_obj.SetLastRadialAxisProperty,
                        deref_vtk(arg))
        self.trait_property_changed('last_radial_axis_property', old_val, arg)
    last_radial_axis_property = traits.Property(_get_last_radial_axis_property, _set_last_radial_axis_property, desc=\
        r"""
        
        """
    )

    def _get_last_radial_axis_text_property(self):
        return wrap_vtk(self._vtk_obj.GetLastRadialAxisTextProperty())
    def _set_last_radial_axis_text_property(self, arg):
        old_val = self._get_last_radial_axis_text_property()
        self._wrap_call(self._vtk_obj.SetLastRadialAxisTextProperty,
                        deref_vtk(arg))
        self.trait_property_changed('last_radial_axis_text_property', old_val, arg)
    last_radial_axis_text_property = traits.Property(_get_last_radial_axis_text_property, _set_last_radial_axis_text_property, desc=\
        r"""
        
        """
    )

    maximum_angle = traits.Float(90.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the maximum radius of the polar coordinates (in degrees).
        Default: 90.
        """
    )

    def _maximum_angle_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumAngle,
                        self.maximum_angle)

    maximum_radius = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the maximum radius of the polar coordinates. Default: 1.
        """
    )

    def _maximum_radius_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMaximumRadius,
                        self.maximum_radius)

    minimum_angle = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the minimum radius of the polar coordinates (in degrees).
        Default: 0.
        """
    )

    def _minimum_angle_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMinimumAngle,
                        self.minimum_angle)

    minimum_radius = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the minimal radius of the polar coordinates. Default: 0.
        """
    )

    def _minimum_radius_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetMinimumRadius,
                        self.minimum_radius)

    number_of_polar_axis_ticks = traits.Int(11, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get a number of ticks that one would like to display along
        polar axis. NB: it modifies delta_range_major to correspond to this
        number.
        """
    )

    def _number_of_polar_axis_ticks_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfPolarAxisTicks,
                        self.number_of_polar_axis_ticks)

    polar_arc_resolution_per_degree = traits.Trait(0.2, traits.Range(0.05, 100.0, enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the number of line per degree to draw polar arc. Default:
        0.2.
        """
    )

    def _polar_arc_resolution_per_degree_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarArcResolutionPerDegree,
                        self.polar_arc_resolution_per_degree)

    def _get_polar_arcs_property(self):
        return wrap_vtk(self._vtk_obj.GetPolarArcsProperty())
    def _set_polar_arcs_property(self, arg):
        old_val = self._get_polar_arcs_property()
        self._wrap_call(self._vtk_obj.SetPolarArcsProperty,
                        deref_vtk(arg))
        self.trait_property_changed('polar_arcs_property', old_val, arg)
    polar_arcs_property = traits.Property(_get_polar_arcs_property, _set_polar_arcs_property, desc=\
        r"""
        
        """
    )

    def _get_polar_axis_label_text_property(self):
        return wrap_vtk(self._vtk_obj.GetPolarAxisLabelTextProperty())
    def _set_polar_axis_label_text_property(self, arg):
        old_val = self._get_polar_axis_label_text_property()
        self._wrap_call(self._vtk_obj.SetPolarAxisLabelTextProperty,
                        deref_vtk(arg))
        self.trait_property_changed('polar_axis_label_text_property', old_val, arg)
    polar_axis_label_text_property = traits.Property(_get_polar_axis_label_text_property, _set_polar_axis_label_text_property, desc=\
        r"""
        
        """
    )

    polar_axis_major_tick_size = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the size of the major ticks on the polar axis. If set to
        0, compute it as a ratio of maximum radius. Default 0.
        """
    )

    def _polar_axis_major_tick_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisMajorTickSize,
                        self.polar_axis_major_tick_size)

    polar_axis_major_tick_thickness = traits.Float(1.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the size of the thickness of polar axis ticks. Default:
        1.
        """
    )

    def _polar_axis_major_tick_thickness_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisMajorTickThickness,
                        self.polar_axis_major_tick_thickness)

    def _get_polar_axis_property(self):
        return wrap_vtk(self._vtk_obj.GetPolarAxisProperty())
    def _set_polar_axis_property(self, arg):
        old_val = self._get_polar_axis_property()
        self._wrap_call(self._vtk_obj.SetPolarAxisProperty,
                        deref_vtk(arg))
        self.trait_property_changed('polar_axis_property', old_val, arg)
    polar_axis_property = traits.Property(_get_polar_axis_property, _set_polar_axis_property, desc=\
        r"""
        
        """
    )

    polar_axis_tick_ratio_size = traits.Float(0.3, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between major and minor Polar Axis ticks size.
        Default: 0.3.
        """
    )

    def _polar_axis_tick_ratio_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisTickRatioSize,
                        self.polar_axis_tick_ratio_size)

    polar_axis_tick_ratio_thickness = traits.Float(0.5, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between major and minor Polar Axis ticks
        thickness. Default: 0.5.
        """
    )

    def _polar_axis_tick_ratio_thickness_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisTickRatioThickness,
                        self.polar_axis_tick_ratio_thickness)

    polar_axis_title = traits.String('Radial Distance', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the labels for the polar axis. Default: "Radial
        Distance".
        """
    )

    def _polar_axis_title_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisTitle,
                        self.polar_axis_title)

    polar_axis_title_location = traits.Trait(0, traits.Range(0, 1, enter_set=True, auto_set=False), desc=\
        r"""
        Get/Set the alignment of the polar axes title related to the
        axis. Possible Alignment: VTKTITLE_BOTTOM, VTK_TITLE_EXTERN.
        Default: VTK_TITLE_BOTTOM.
        """
    )

    def _polar_axis_title_location_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarAxisTitleLocation,
                        self.polar_axis_title_location)

    def _get_polar_axis_title_text_property(self):
        return wrap_vtk(self._vtk_obj.GetPolarAxisTitleTextProperty())
    def _set_polar_axis_title_text_property(self, arg):
        old_val = self._get_polar_axis_title_text_property()
        self._wrap_call(self._vtk_obj.SetPolarAxisTitleTextProperty,
                        deref_vtk(arg))
        self.trait_property_changed('polar_axis_title_text_property', old_val, arg)
    polar_axis_title_text_property = traits.Property(_get_polar_axis_title_text_property, _set_polar_axis_title_text_property, desc=\
        r"""
        
        """
    )

    polar_exponent_offset = traits.Float(5.0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _polar_exponent_offset_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarExponentOffset,
                        self.polar_exponent_offset)

    polar_label_format = traits.String('%-#6.3g', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the format with which to print the polar axis labels.
        """
    )

    def _polar_label_format_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarLabelFormat,
                        self.polar_label_format)

    polar_label_offset = traits.Float(10.0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _polar_label_offset_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarLabelOffset,
                        self.polar_label_offset)

    polar_title_offset = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype="float", value=(20.0, 10.0), cols=2, desc=\
        r"""
        Set/Get the polar title offset. X-component is used only if text
        is not aligned to center. Default: (20, 10).
        """
    )

    def _polar_title_offset_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPolarTitleOffset,
                        self.polar_title_offset)

    pole = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(0.0, 0.0, 0.0), cols=3, desc=\
        r"""
        Explicitly specify the coordinate of the pole.
        """
    )

    def _pole_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetPole,
                        self.pole)

    radial_angle_format = traits.String('%-#3.1f', enter_set=True, auto_set=False, desc=\
        r"""
        String to format angle values displayed on the radial axes.
        """
    )

    def _radial_angle_format_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialAngleFormat,
                        self.radial_angle_format)

    radial_axis_title_location = traits.Trait(0, traits.Range(0, 1, enter_set=True, auto_set=False), desc=\
        r"""
        Get/Set the alignment of the radial axes title related to the
        axis. Possible Alignment: VTK_TITLE_BOTTOM, VTK_TITLE_EXTERN.
        Default: VTK_TITLE_BOTTOM.
        """
    )

    def _radial_axis_title_location_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialAxisTitleLocation,
                        self.radial_axis_title_location)

    radial_title_offset = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype="float", value=(20.0, 0.0), cols=2, desc=\
        r"""
        Set/Get the radial title offset. X-component is used only if text
        is not aligned to center. Default: (20, 0).
        """
    )

    def _radial_title_offset_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialTitleOffset,
                        self.radial_title_offset)

    radial_units = traits.Bool(True, enter_set=True, auto_set=False, desc=\
        r"""
        Default: true
        """
    )

    def _radial_units_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRadialUnits,
                        self.radial_units)

    range = traits.Array(enter_set=True, auto_set=False, shape=(2,), dtype="float", value=(0.0, 10.0), cols=2, desc=\
        r"""
        Define the range values displayed on the polar Axis. Default: (0,
        10).
        """
    )

    def _range_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRange,
                        self.range)

    ratio = traits.Trait(1.0, traits.Range(0.001, 100.0, enter_set=True, auto_set=False), desc=\
        r"""
        Ratio. Default: 1.
        """
    )

    def _ratio_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRatio,
                        self.ratio)

    requested_delta_angle_radial_axes = traits.Float(45.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get requested delta angle for radial axes. If set to 0,
        compute it depending on count. Default: 45.
        """
    )

    def _requested_delta_angle_radial_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRequestedDeltaAngleRadialAxes,
                        self.requested_delta_angle_radial_axes)

    requested_delta_range_polar_axes = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get requested delta range for polar axes. If set to 0,
        compute it depending on count. Default: 0.
        """
    )

    def _requested_delta_range_polar_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRequestedDeltaRangePolarAxes,
                        self.requested_delta_range_polar_axes)

    requested_number_of_polar_axes = traits.Trait(5, traits.Range(0, 20, enter_set=True, auto_set=False), desc=\
        r"""
        Gets/Sets the number of polar axes. Default: 5.
        """
    )

    def _requested_number_of_polar_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRequestedNumberOfPolarAxes,
                        self.requested_number_of_polar_axes)

    requested_number_of_radial_axes = traits.Trait(0, traits.Range(0, 50, enter_set=True, auto_set=False), desc=\
        r"""
        Gets/Sets the number of radial axes. Default: 0.
        """
    )

    def _requested_number_of_radial_axes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRequestedNumberOfRadialAxes,
                        self.requested_number_of_radial_axes)

    screen_size = traits.Float(10.0, enter_set=True, auto_set=False, desc=\
        r"""
        Explicitly specify the screen size of title and label text.
        screen_size determines the size of the text in terms of screen
        pixels. Default: 10.0.
        """
    )

    def _screen_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetScreenSize,
                        self.screen_size)

    def _get_secondary_polar_arcs_property(self):
        return wrap_vtk(self._vtk_obj.GetSecondaryPolarArcsProperty())
    def _set_secondary_polar_arcs_property(self, arg):
        old_val = self._get_secondary_polar_arcs_property()
        self._wrap_call(self._vtk_obj.SetSecondaryPolarArcsProperty,
                        deref_vtk(arg))
        self.trait_property_changed('secondary_polar_arcs_property', old_val, arg)
    secondary_polar_arcs_property = traits.Property(_get_secondary_polar_arcs_property, _set_secondary_polar_arcs_property, desc=\
        r"""
        
        """
    )

    def _get_secondary_radial_axes_property(self):
        return wrap_vtk(self._vtk_obj.GetSecondaryRadialAxesProperty())
    def _set_secondary_radial_axes_property(self, arg):
        old_val = self._get_secondary_radial_axes_property()
        self._wrap_call(self._vtk_obj.SetSecondaryRadialAxesProperty,
                        deref_vtk(arg))
        self.trait_property_changed('secondary_radial_axes_property', old_val, arg)
    secondary_radial_axes_property = traits.Property(_get_secondary_radial_axes_property, _set_secondary_radial_axes_property, desc=\
        r"""
        
        """
    )

    def _get_secondary_radial_axes_text_property(self):
        return wrap_vtk(self._vtk_obj.GetSecondaryRadialAxesTextProperty())
    def _set_secondary_radial_axes_text_property(self, arg):
        old_val = self._get_secondary_radial_axes_text_property()
        self._wrap_call(self._vtk_obj.SetSecondaryRadialAxesTextProperty,
                        deref_vtk(arg))
        self.trait_property_changed('secondary_radial_axes_text_property', old_val, arg)
    secondary_radial_axes_text_property = traits.Property(_get_secondary_radial_axes_text_property, _set_secondary_radial_axes_text_property, desc=\
        r"""
        
        """
    )

    smallest_visible_polar_angle = traits.Trait(0.5, traits.Range(0.0, 5.0, enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the minimum radial angle distinguishable from polar axis.
        NB: This is used only when polar axis is visible. Default: 0.5.
        """
    )

    def _smallest_visible_polar_angle_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetSmallestVisiblePolarAngle,
                        self.smallest_visible_polar_angle)

    tick_location = traits.Trait(2, traits.Range(0, 2, enter_set=True, auto_set=False), desc=\
        r"""
        Set/Get the location of the ticks. Inside: tick end toward
        positive direction of perpendicular axes. Outside: tick end
        toward negative direction of perpendicular axes. Default:
        VTK_TICKS_BOTH.
        """
    )

    def _tick_location_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTickLocation,
                        self.tick_location)

    tick_ratio_radius_size = traits.Float(0.02, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the ratio between maximum radius and major ticks size.
        Default: 0.02.
        """
    )

    def _tick_ratio_radius_size_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetTickRatioRadiusSize,
                        self.tick_ratio_radius_size)

    use2d_mode = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Enable/Disable labels 2D mode (always facing the camera).
        """
    )

    def _use2d_mode_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUse2DMode,
                        self.use2d_mode)

    view_angle_lod_threshold = traits.Trait(0.3, traits.Range(0.0, 1.0, enter_set=True, auto_set=False), desc=\
        r"""
        Set view angle LOD threshold [0.0 - 1.0] for titles and labels.
        Default: 0.3.
        """
    )

    def _view_angle_lod_threshold_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetViewAngleLODThreshold,
                        self.view_angle_lod_threshold)

    _updateable_traits_ = \
    (('arc_minor_tick_visibility', 'GetArcMinorTickVisibility'),
    ('arc_tick_matches_radial_axes', 'GetArcTickMatchesRadialAxes'),
    ('arc_tick_visibility', 'GetArcTickVisibility'),
    ('arc_ticks_origin_to_polar_axis', 'GetArcTicksOriginToPolarAxis'),
    ('auto_subdivide_polar_axis', 'GetAutoSubdividePolarAxis'),
    ('axis_minor_tick_visibility', 'GetAxisMinorTickVisibility'),
    ('axis_tick_matches_polar_axes', 'GetAxisTickMatchesPolarAxes'),
    ('axis_tick_visibility', 'GetAxisTickVisibility'),
    ('draw_polar_arcs_gridlines', 'GetDrawPolarArcsGridlines'),
    ('draw_radial_gridlines', 'GetDrawRadialGridlines'), ('log',
    'GetLog'), ('polar_arcs_visibility', 'GetPolarArcsVisibility'),
    ('polar_axis_visibility', 'GetPolarAxisVisibility'),
    ('polar_label_visibility', 'GetPolarLabelVisibility'),
    ('polar_tick_visibility', 'GetPolarTickVisibility'),
    ('polar_title_visibility', 'GetPolarTitleVisibility'),
    ('radial_axes_origin_to_polar_axis',
    'GetRadialAxesOriginToPolarAxis'), ('radial_axes_visibility',
    'GetRadialAxesVisibility'), ('radial_title_visibility',
    'GetRadialTitleVisibility'), ('force_opaque', 'GetForceOpaque'),
    ('force_translucent', 'GetForceTranslucent'), ('dragable',
    'GetDragable'), ('pickable', 'GetPickable'), ('use_bounds',
    'GetUseBounds'), ('visibility', 'GetVisibility'), ('debug',
    'GetDebug'), ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('coordinate_system', 'GetCoordinateSystem'), ('arc_major_tick_size',
    'GetArcMajorTickSize'), ('arc_major_tick_thickness',
    'GetArcMajorTickThickness'), ('arc_tick_ratio_size',
    'GetArcTickRatioSize'), ('arc_tick_ratio_thickness',
    'GetArcTickRatioThickness'), ('bounds', 'GetBounds'),
    ('delta_angle_major', 'GetDeltaAngleMajor'), ('delta_angle_minor',
    'GetDeltaAngleMinor'), ('delta_range_major', 'GetDeltaRangeMajor'),
    ('delta_range_minor', 'GetDeltaRangeMinor'),
    ('distance_lod_threshold', 'GetDistanceLODThreshold'),
    ('enable_distance_lod', 'GetEnableDistanceLOD'),
    ('enable_view_angle_lod', 'GetEnableViewAngleLOD'),
    ('exponent_location', 'GetExponentLocation'),
    ('last_axis_tick_ratio_size', 'GetLastAxisTickRatioSize'),
    ('last_axis_tick_ratio_thickness', 'GetLastAxisTickRatioThickness'),
    ('last_radial_axis_major_tick_size',
    'GetLastRadialAxisMajorTickSize'),
    ('last_radial_axis_major_tick_thickness',
    'GetLastRadialAxisMajorTickThickness'), ('maximum_angle',
    'GetMaximumAngle'), ('maximum_radius', 'GetMaximumRadius'),
    ('minimum_angle', 'GetMinimumAngle'), ('minimum_radius',
    'GetMinimumRadius'), ('number_of_polar_axis_ticks',
    'GetNumberOfPolarAxisTicks'), ('polar_arc_resolution_per_degree',
    'GetPolarArcResolutionPerDegree'), ('polar_axis_major_tick_size',
    'GetPolarAxisMajorTickSize'), ('polar_axis_major_tick_thickness',
    'GetPolarAxisMajorTickThickness'), ('polar_axis_tick_ratio_size',
    'GetPolarAxisTickRatioSize'), ('polar_axis_tick_ratio_thickness',
    'GetPolarAxisTickRatioThickness'), ('polar_axis_title',
    'GetPolarAxisTitle'), ('polar_axis_title_location',
    'GetPolarAxisTitleLocation'), ('polar_exponent_offset',
    'GetPolarExponentOffset'), ('polar_label_format',
    'GetPolarLabelFormat'), ('polar_label_offset', 'GetPolarLabelOffset'),
    ('polar_title_offset', 'GetPolarTitleOffset'), ('pole', 'GetPole'),
    ('radial_angle_format', 'GetRadialAngleFormat'),
    ('radial_axis_title_location', 'GetRadialAxisTitleLocation'),
    ('radial_title_offset', 'GetRadialTitleOffset'), ('radial_units',
    'GetRadialUnits'), ('range', 'GetRange'), ('ratio', 'GetRatio'),
    ('requested_delta_angle_radial_axes',
    'GetRequestedDeltaAngleRadialAxes'),
    ('requested_delta_range_polar_axes',
    'GetRequestedDeltaRangePolarAxes'), ('requested_number_of_polar_axes',
    'GetRequestedNumberOfPolarAxes'), ('requested_number_of_radial_axes',
    'GetRequestedNumberOfRadialAxes'), ('screen_size', 'GetScreenSize'),
    ('smallest_visible_polar_angle', 'GetSmallestVisiblePolarAngle'),
    ('tick_location', 'GetTickLocation'), ('tick_ratio_radius_size',
    'GetTickRatioRadiusSize'), ('use2d_mode', 'GetUse2DMode'),
    ('view_angle_lod_threshold', 'GetViewAngleLODThreshold'),
    ('coordinate_system_device', 'GetCoordinateSystemDevice'),
    ('orientation', 'GetOrientation'), ('origin', 'GetOrigin'),
    ('position', 'GetPosition'), ('scale', 'GetScale'),
    ('estimated_render_time', 'GetEstimatedRenderTime'),
    ('render_time_multiplier', 'GetRenderTimeMultiplier'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['arc_minor_tick_visibility', 'arc_tick_matches_radial_axes',
    'arc_tick_visibility', 'arc_ticks_origin_to_polar_axis',
    'auto_subdivide_polar_axis', 'axis_minor_tick_visibility',
    'axis_tick_matches_polar_axes', 'axis_tick_visibility', 'debug',
    'dragable', 'draw_polar_arcs_gridlines', 'draw_radial_gridlines',
    'force_opaque', 'force_translucent', 'global_warning_display', 'log',
    'pickable', 'polar_arcs_visibility', 'polar_axis_visibility',
    'polar_label_visibility', 'polar_tick_visibility',
    'polar_title_visibility', 'radial_axes_origin_to_polar_axis',
    'radial_axes_visibility', 'radial_title_visibility', 'use_bounds',
    'visibility', 'coordinate_system', 'arc_major_tick_size',
    'arc_major_tick_thickness', 'arc_tick_ratio_size',
    'arc_tick_ratio_thickness', 'bounds', 'coordinate_system_device',
    'delta_angle_major', 'delta_angle_minor', 'delta_range_major',
    'delta_range_minor', 'distance_lod_threshold', 'enable_distance_lod',
    'enable_view_angle_lod', 'estimated_render_time', 'exponent_location',
    'last_axis_tick_ratio_size', 'last_axis_tick_ratio_thickness',
    'last_radial_axis_major_tick_size',
    'last_radial_axis_major_tick_thickness', 'maximum_angle',
    'maximum_radius', 'minimum_angle', 'minimum_radius',
    'number_of_polar_axis_ticks', 'object_name', 'orientation', 'origin',
    'polar_arc_resolution_per_degree', 'polar_axis_major_tick_size',
    'polar_axis_major_tick_thickness', 'polar_axis_tick_ratio_size',
    'polar_axis_tick_ratio_thickness', 'polar_axis_title',
    'polar_axis_title_location', 'polar_exponent_offset',
    'polar_label_format', 'polar_label_offset', 'polar_title_offset',
    'pole', 'position', 'radial_angle_format',
    'radial_axis_title_location', 'radial_title_offset', 'radial_units',
    'range', 'ratio', 'render_time_multiplier',
    'requested_delta_angle_radial_axes',
    'requested_delta_range_polar_axes', 'requested_number_of_polar_axes',
    'requested_number_of_radial_axes', 'scale', 'screen_size',
    'smallest_visible_polar_angle', 'tick_location',
    'tick_ratio_radius_size', 'use2d_mode', 'view_angle_lod_threshold'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PolarAxesActor, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PolarAxesActor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['arc_minor_tick_visibility', 'arc_tick_matches_radial_axes',
            'arc_tick_visibility', 'arc_ticks_origin_to_polar_axis',
            'auto_subdivide_polar_axis', 'axis_minor_tick_visibility',
            'axis_tick_matches_polar_axes', 'axis_tick_visibility',
            'draw_polar_arcs_gridlines', 'draw_radial_gridlines', 'force_opaque',
            'force_translucent', 'log', 'polar_arcs_visibility',
            'polar_axis_visibility', 'polar_label_visibility',
            'polar_tick_visibility', 'polar_title_visibility',
            'radial_axes_origin_to_polar_axis', 'radial_axes_visibility',
            'radial_title_visibility', 'use_bounds', 'visibility'],
            ['coordinate_system'], ['arc_major_tick_size',
            'arc_major_tick_thickness', 'arc_tick_ratio_size',
            'arc_tick_ratio_thickness', 'bounds', 'coordinate_system_device',
            'delta_angle_major', 'delta_angle_minor', 'delta_range_major',
            'delta_range_minor', 'distance_lod_threshold', 'enable_distance_lod',
            'enable_view_angle_lod', 'estimated_render_time', 'exponent_location',
            'last_axis_tick_ratio_size', 'last_axis_tick_ratio_thickness',
            'last_radial_axis_major_tick_size',
            'last_radial_axis_major_tick_thickness', 'maximum_angle',
            'maximum_radius', 'minimum_angle', 'minimum_radius',
            'number_of_polar_axis_ticks', 'object_name', 'orientation', 'origin',
            'polar_arc_resolution_per_degree', 'polar_axis_major_tick_size',
            'polar_axis_major_tick_thickness', 'polar_axis_tick_ratio_size',
            'polar_axis_tick_ratio_thickness', 'polar_axis_title',
            'polar_axis_title_location', 'polar_exponent_offset',
            'polar_label_format', 'polar_label_offset', 'polar_title_offset',
            'pole', 'position', 'radial_angle_format',
            'radial_axis_title_location', 'radial_title_offset', 'radial_units',
            'range', 'ratio', 'render_time_multiplier',
            'requested_delta_angle_radial_axes',
            'requested_delta_range_polar_axes', 'requested_number_of_polar_axes',
            'requested_number_of_radial_axes', 'scale', 'screen_size',
            'smallest_visible_polar_angle', 'tick_location',
            'tick_ratio_radius_size', 'use2d_mode', 'view_angle_lod_threshold']),
            title='Edit PolarAxesActor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PolarAxesActor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

