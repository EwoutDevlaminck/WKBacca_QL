# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.actor import Actor


class Skybox(Actor):
    r"""
    Skybox - Renders a skybox environment
    
    Superclass: Actor
    
    You must provide a texture cube map using the set_texture method.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkSkybox, obj, update, **traits)
    
    gamma_correct = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _gamma_correct_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGammaCorrect,
                        self.gamma_correct_)

    projection = tvtk_base.RevPrefixMap({'cube': 0, 'floor': 2, 'sphere': 1, 'stereo_sphere': 3}, default_value='cube', desc=\
        r"""
        
        """
    )

    def _projection_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetProjection,
                        self.projection_)

    floor_plane = traits.Array(enter_set=True, auto_set=False, shape=(4,), dtype="float", value=(0.0, 1.0, 0.0, 0.0), cols=3, desc=\
        r"""
        Set/Get the plane equation for the floor.
        """
    )

    def _floor_plane_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFloorPlane,
                        self.floor_plane)

    floor_right = traits.Array(enter_set=True, auto_set=False, shape=(3,), dtype="float", value=(1.0, 0.0, 0.0), cols=3, desc=\
        r"""
        
        """
    )

    def _floor_right_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetFloorRight,
                        self.floor_right)

    _updateable_traits_ = \
    (('gamma_correct', 'GetGammaCorrect'), ('force_opaque',
    'GetForceOpaque'), ('force_translucent', 'GetForceTranslucent'),
    ('dragable', 'GetDragable'), ('pickable', 'GetPickable'),
    ('use_bounds', 'GetUseBounds'), ('visibility', 'GetVisibility'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('projection', 'GetProjection'),
    ('coordinate_system', 'GetCoordinateSystem'), ('floor_plane',
    'GetFloorPlane'), ('floor_right', 'GetFloorRight'),
    ('coordinate_system_device', 'GetCoordinateSystemDevice'),
    ('orientation', 'GetOrientation'), ('origin', 'GetOrigin'),
    ('position', 'GetPosition'), ('scale', 'GetScale'),
    ('estimated_render_time', 'GetEstimatedRenderTime'),
    ('render_time_multiplier', 'GetRenderTimeMultiplier'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'dragable', 'force_opaque', 'force_translucent',
    'gamma_correct', 'global_warning_display', 'pickable', 'use_bounds',
    'visibility', 'coordinate_system', 'projection',
    'coordinate_system_device', 'estimated_render_time', 'floor_plane',
    'floor_right', 'object_name', 'orientation', 'origin', 'position',
    'render_time_multiplier', 'scale'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(Skybox, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit Skybox properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['force_opaque', 'force_translucent', 'gamma_correct',
            'use_bounds', 'visibility'], ['coordinate_system', 'projection'],
            ['coordinate_system_device', 'estimated_render_time', 'floor_plane',
            'floor_right', 'object_name', 'orientation', 'origin', 'position',
            'render_time_multiplier', 'scale']),
            title='Edit Skybox properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit Skybox properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

