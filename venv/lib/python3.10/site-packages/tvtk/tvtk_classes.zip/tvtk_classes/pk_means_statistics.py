# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.k_means_statistics import KMeansStatistics


class PKMeansStatistics(KMeansStatistics):
    r"""
    PKMeansStatistics - no description provided.
    
    Superclass: KMeansStatistics
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPKMeansStatistics, obj, update, **traits)
    
    def _get_controller(self):
        return wrap_vtk(self._vtk_obj.GetController())
    def _set_controller(self, arg):
        old_val = self._get_controller()
        self._wrap_call(self._vtk_obj.SetController,
                        deref_vtk(arg))
        self.trait_property_changed('controller', old_val, arg)
    controller = traits.Property(_get_controller, _set_controller, desc=\
        r"""
        
        """
    )

    def get_total_number_of_observations(self, *args):
        """
        get_total_number_of_observations(self, numObservations:int) -> int
        C++: IdType get_total_number_of_observations(
            IdType numObservations) override;
        Subroutine to get the total number of data objects.
        """
        ret = self._wrap_call(self._vtk_obj.GetTotalNumberOfObservations, *args)
        return ret

    def create_initial_cluster_centers(self, *args):
        """
        create_initial_cluster_centers(self, numToAllocate:int,
            numberOfClusters:IdTypeArray, inData:Table,
            curClusterElements:Table, newClusterElements:Table)
            -> None
        C++: void create_initial_cluster_centers(IdType numToAllocate,
            IdTypeArray *numberOfClusters, Table *inData,
            Table *curClusterElements, Table *newClusterElements)
            override;
        Subroutine to initialize cluster centerss if not provided by the
        user.
        """
        my_args = deref_array(args, [('int', 'vtkIdTypeArray', 'vtkTable', 'vtkTable', 'vtkTable')])
        ret = self._wrap_call(self._vtk_obj.CreateInitialClusterCenters, *my_args)
        return ret

    def update_cluster_centers(self, *args):
        """
        update_cluster_centers(self, newClusterElements:Table,
            curClusterElements:Table,
            numMembershipChanges:IdTypeArray,
            numElementsInCluster:IdTypeArray, error:DoubleArray,
            startRunID:IdTypeArray, endRunID:IdTypeArray,
            computeRun:IntArray) -> None
        C++: void update_cluster_centers(Table *newClusterElements,
            Table *curClusterElements,
            IdTypeArray *numMembershipChanges,
            IdTypeArray *numElementsInCluster, DoubleArray *error,
            IdTypeArray *startRunID, IdTypeArray *endRunID,
            IntArray *computeRun) override;
        Subroutine to update new cluster centers from the old centers.
        """
        my_args = deref_array(args, [('vtkTable', 'vtkTable', 'vtkIdTypeArray', 'vtkIdTypeArray', 'vtkDoubleArray', 'vtkIdTypeArray', 'vtkIdTypeArray', 'vtkIntArray')])
        ret = self._wrap_call(self._vtk_obj.UpdateClusterCenters, *my_args)
        return ret

    _updateable_traits_ = \
    (('abort_execute', 'GetAbortExecute'), ('release_data_flag',
    'GetReleaseDataFlag'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('default_number_of_clusters', 'GetDefaultNumberOfClusters'),
    ('ghosts_to_skip', 'GetGhostsToSkip'), ('k_values_array_name',
    'GetKValuesArrayName'), ('max_num_iterations', 'GetMaxNumIterations'),
    ('tolerance', 'GetTolerance'), ('assess_option', 'GetAssessOption'),
    ('derive_option', 'GetDeriveOption'), ('learn_option',
    'GetLearnOption'), ('number_of_primary_tables',
    'GetNumberOfPrimaryTables'), ('test_option', 'GetTestOption'),
    ('abort_output', 'GetAbortOutput'), ('progress_text',
    'GetProgressText'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'global_warning_display',
    'release_data_flag', 'abort_output', 'assess_option',
    'default_number_of_clusters', 'derive_option', 'ghosts_to_skip',
    'k_values_array_name', 'learn_option', 'max_num_iterations',
    'number_of_primary_tables', 'object_name', 'progress_text',
    'test_option', 'tolerance'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PKMeansStatistics, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PKMeansStatistics properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['abort_output', 'assess_option',
            'default_number_of_clusters', 'derive_option', 'ghosts_to_skip',
            'k_values_array_name', 'learn_option', 'max_num_iterations',
            'number_of_primary_tables', 'object_name', 'test_option',
            'tolerance']),
            title='Edit PKMeansStatistics properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PKMeansStatistics properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

