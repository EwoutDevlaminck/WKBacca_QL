# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.avatar import Avatar


class OpenGLAvatar(Avatar):
    r"""
    OpenGLAvatar - open_gl Avatar
    
    Superclass: Avatar
    
    OpenGLAvatar is a concrete implementation of the abstract class
    Avatar. OpenGLAvatar interfaces to the open_gl rendering
    library.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkOpenGLAvatar, obj, update, **traits)
    
    def _get_label_text_property(self):
        return wrap_vtk(self._vtk_obj.GetLabelTextProperty())
    label_text_property = traits.Property(_get_label_text_property, desc=\
        r"""
        
        """
    )

    def set_label(self, *args):
        """
        set_label(self, label:str) -> None
        C++: void set_label(const char *label)"""
        ret = self._wrap_call(self._vtk_obj.SetLabel, *args)
        return ret

    def set_left_show_ray(self, *args):
        """
        set_left_show_ray(self, v:bool) -> None
        C++: void set_left_show_ray(bool v)"""
        ret = self._wrap_call(self._vtk_obj.SetLeftShowRay, *args)
        return ret

    def set_ray_length(self, *args):
        """
        set_ray_length(self, length:float) -> None
        C++: void set_ray_length(double length)"""
        ret = self._wrap_call(self._vtk_obj.SetRayLength, *args)
        return ret

    def set_right_show_ray(self, *args):
        """
        set_right_show_ray(self, v:bool) -> None
        C++: void set_right_show_ray(bool v)"""
        ret = self._wrap_call(self._vtk_obj.SetRightShowRay, *args)
        return ret

    _updateable_traits_ = \
    (('show_hands_only', 'GetShowHandsOnly'), ('use_left_hand',
    'GetUseLeftHand'), ('use_right_hand', 'GetUseRightHand'),
    ('force_opaque', 'GetForceOpaque'), ('force_translucent',
    'GetForceTranslucent'), ('dragable', 'GetDragable'), ('pickable',
    'GetPickable'), ('use_bounds', 'GetUseBounds'), ('visibility',
    'GetVisibility'), ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('coordinate_system',
    'GetCoordinateSystem'), ('head_orientation', 'GetHeadOrientation'),
    ('head_position', 'GetHeadPosition'), ('left_hand_orientation',
    'GetLeftHandOrientation'), ('left_hand_position',
    'GetLeftHandPosition'), ('right_hand_orientation',
    'GetRightHandOrientation'), ('right_hand_position',
    'GetRightHandPosition'), ('up_vector', 'GetUpVector'),
    ('coordinate_system_device', 'GetCoordinateSystemDevice'),
    ('orientation', 'GetOrientation'), ('origin', 'GetOrigin'),
    ('position', 'GetPosition'), ('scale', 'GetScale'),
    ('estimated_render_time', 'GetEstimatedRenderTime'),
    ('render_time_multiplier', 'GetRenderTimeMultiplier'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'dragable', 'force_opaque', 'force_translucent',
    'global_warning_display', 'pickable', 'show_hands_only', 'use_bounds',
    'use_left_hand', 'use_right_hand', 'visibility', 'coordinate_system',
    'coordinate_system_device', 'estimated_render_time',
    'head_orientation', 'head_position', 'left_hand_orientation',
    'left_hand_position', 'object_name', 'orientation', 'origin',
    'position', 'render_time_multiplier', 'right_hand_orientation',
    'right_hand_position', 'scale', 'up_vector'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(OpenGLAvatar, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit OpenGLAvatar properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['force_opaque', 'force_translucent', 'show_hands_only',
            'use_bounds', 'use_left_hand', 'use_right_hand', 'visibility'],
            ['coordinate_system'], ['coordinate_system_device',
            'estimated_render_time', 'head_orientation', 'head_position',
            'left_hand_orientation', 'left_hand_position', 'object_name',
            'orientation', 'origin', 'position', 'render_time_multiplier',
            'right_hand_orientation', 'right_hand_position', 'scale',
            'up_vector']),
            title='Edit OpenGLAvatar properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit OpenGLAvatar properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

