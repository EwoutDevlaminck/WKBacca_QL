# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.extract_exodus_global_temporal_variables import ExtractExodusGlobalTemporalVariables


class PExtractExodusGlobalTemporalVariables(ExtractExodusGlobalTemporalVariables):
    r"""
    PExtractExodusGlobalTemporalVariables - parallel version of
    ExtractExodusGlobalTemporalVariables.
    
    Superclass: ExtractExodusGlobalTemporalVariables
    
    PExtractExodusGlobalTemporalVariables is a parallel version of
    ExtractExodusGlobalTemporalVariables that handles synchronization
    between multiple ranks. Since PExodusIIReader has explicit
    sycnchronization between ranks its essential that downstream filters
    make consistent requests on all ranks to avoid deadlocks. Since
    global variables need not be provided on all ranks, without explicit
    coordination ExtractExodusGlobalTemporalVariables may end up not
    making requests on certain ranks causing deadlocks.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkPExtractExodusGlobalTemporalVariables, obj, update, **traits)
    
    def _get_controller(self):
        return wrap_vtk(self._vtk_obj.GetController())
    def _set_controller(self, arg):
        old_val = self._get_controller()
        self._wrap_call(self._vtk_obj.SetController,
                        deref_vtk(arg))
        self.trait_property_changed('controller', old_val, arg)
    controller = traits.Property(_get_controller, _set_controller, desc=\
        r"""
        
        """
    )

    _updateable_traits_ = \
    (('auto_detect_global_temporal_data_arrays',
    'GetAutoDetectGlobalTemporalDataArrays'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'auto_detect_global_temporal_data_arrays', 'debug',
    'global_warning_display', 'release_data_flag', 'abort_output',
    'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(PExtractExodusGlobalTemporalVariables, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit PExtractExodusGlobalTemporalVariables properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['auto_detect_global_temporal_data_arrays'], [],
            ['abort_output', 'object_name']),
            title='Edit PExtractExodusGlobalTemporalVariables properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit PExtractExodusGlobalTemporalVariables properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

