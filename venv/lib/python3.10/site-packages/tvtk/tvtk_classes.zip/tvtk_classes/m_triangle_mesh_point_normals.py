# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.triangle_mesh_point_normals import TriangleMeshPointNormals


class mTriangleMeshPointNormals(TriangleMeshPointNormals):
    r"""
    vtkmTriangleMeshPointNormals - compute point normals for triangle mesh
    
    Superclass: TriangleMeshPointNormals
    
    vtkmTriangleMeshPointNormals is a filter that computes point normals
    for a triangle mesh to enable high-performance rendering. It is a
    fast-path version of the vtkmPolyDataNormals filter in order to be
    able to compute normals for triangle meshes deforming rapidly.
    
    The computed normals (a FloatArray) are set to be the active
    normals (using set_normals()) of the point_data. The array name is
    "Normals".
    
    The algorithm works by determining normals for each triangle and
    adding these vectors to the triangle points. The resulting vectors at
    each point are then normalized.
    
    @warning
    Normals are computed only for triangular polygons: the filter can not
    handle meshes with other types of cells (Verts, Lines, Strips) or
    Polys with the wrong number of components (not equal to 3).
    
    @warning
    Unlike the PolyDataNormals filter, this filter does not apply any
    splitting nor checks for cell orientation consistency in order to
    speed up the computation. Moreover, normals are not calculated the
    exact same way as the PolyDataNormals filter since the triangle
    normals are not normalized before being added to the point normals:
    those cell normals are therefore weighted by the triangle area. This
    is not more nor less correct than normalizing them before adding
    them, but it is much faster.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkmTriangleMeshPointNormals, obj, update, **traits)
    
    force_vt_km = tvtk_base.false_bool_trait(desc=\
        r"""
        
        """
    )

    def _force_vt_km_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetForceVTKm,
                        self.force_vt_km_)

    def _get_input(self):
        try:
            return wrap_vtk(self._vtk_obj.GetInput(0))
        except TypeError:
            return wrap_vtk(self._vtk_obj.GetInput())
    input = traits.Property(_get_input,
                            desc="The first input of this object, i.e. the result of `get_input(0)`.")
    
    def get_input(self, *args):
        """
        get_input(self) -> DataObject
        C++: DataObject *get_input()
        get_input(self, port:int) -> DataObject
        C++: DataObject *get_input(int port)"""
        ret = self._wrap_call(self._vtk_obj.GetInput, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('force_vt_km', 'GetForceVTKm'), ('abort_execute',
    'GetAbortExecute'), ('release_data_flag', 'GetReleaseDataFlag'),
    ('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('abort_output', 'GetAbortOutput'),
    ('progress_text', 'GetProgressText'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['abort_execute', 'debug', 'force_vt_km', 'global_warning_display',
    'release_data_flag', 'abort_output', 'object_name', 'progress_text'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(mTriangleMeshPointNormals, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit mTriangleMeshPointNormals properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['force_vt_km'], [], ['abort_output', 'object_name']),
            title='Edit mTriangleMeshPointNormals properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit mTriangleMeshPointNormals properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

